
-- SQL Query to create Contacts table 
CREATE TABLE [dbo].[Contacts](
	Id int IDENTITY(1001,1) NOT NULL,
	FirstName varchar(20) NOT NULL,
	LastName varchar(20) NOT NULL,
	Mobile varchar(14) NULL,
	Email varchar(50) NULL,
	Fax varchar(15) NULL,
	constraint PK_Contacts_Id Primary key(Id)
); 

-- SQL Query for inserting records into Contacts table

insert into Contacts values ('Mike','Jefferson', '0223658475','mikej@live.com','0224575858');
insert into Contacts values ('Praveen','Shinde', '0442356475','praveenonline@live.com','04423569586');
insert into Contacts values ('Sekhar','kumar', '0442653475','sekhar2010@live.com','0442574698');
insert into Contacts values ('James','Watts', '0813256479','jameswatts@live.com','0812452522');

--Query to view all inserted records
Select * from Contacts